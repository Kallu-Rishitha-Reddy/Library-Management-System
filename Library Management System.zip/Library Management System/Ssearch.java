import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Ssearch{

            public String run(int tokenno) throws Exception {

                        FileInputStream fis=new FileInputStream("student.txt");
                        ObjectInputStream ois=new ObjectInputStream(fis);
                        ArrayList al=(ArrayList)ois.readObject();
                        System.out.println(al.get(tokenno));
                        String s1=(String)al.get(tokenno);
                        FileOutputStream fos=new FileOutputStream("student.txt");
                        ObjectOutputStream oos=new ObjectOutputStream(fos);
                        oos.writeObject(al);
                        return s1;
            }
}

class Observe {

            public void observe() throws Exception{

                        FileInputStream fis=new FileInputStream("books.txt");
                        ObjectInputStream ois=new ObjectInputStream(fis);
                        ArrayList al=(ArrayList)ois.readObject();
                        System.out.println(al);
                        FileOutputStream fos=new FileOutputStream("books.txt");
                        ObjectOutputStream oos=new ObjectOutputStream(fos);
                        oos.writeObject(al);
            }
}

class Add{

            public int add() throws Exception

            {

                        FileInputStream fis=new FileInputStream("books.txt");
                        ObjectInputStream ois=new ObjectInputStream(fis);
                        ArrayList al=(ArrayList)ois.readObject();
                        System.out.println("Enter the book to be added:");
                        Scanner scan=new Scanner(System.in);
                        String bname=scan.nextLine();
                        al.add(bname);
                        System.out.println("Book added successfully");
                        FileOutputStream fos=new FileOutputStream("books.txt");
                        ObjectOutputStream oos=new ObjectOutputStream(fos);
                        oos.writeObject(al);
                        return 0;
            }
}

class Issue{

            public void issue()throws Exception{

                        FileInputStream fis=new FileInputStream("books.txt");
                        ObjectInputStream ois=new ObjectInputStream(fis);
                        ArrayList al=(ArrayList)ois.readObject();
                        System.out.println("Enter the Id of book:");
                        Scanner scan=new Scanner(System.in);
                        int bid=scan.nextInt();
                        String book=(String) al.get(bid);
                        System.out.println("Book:"+book);
                        al.remove(bid);
                        System.out.println("Book issued successfully");
                        FileOutputStream fos=new FileOutputStream("books.txt");
                        ObjectOutputStream oos=new ObjectOutputStream(fos);
                        oos.writeObject(al);
                        FileInputStream fis1=new FileInputStream("student.txt");
                        ObjectInputStream ois1=new ObjectInputStream(fis1);
                        ArrayList sl=(ArrayList)ois1.readObject();
                        System.out.println("Enter the candidate name:");
                        String name;
                        name=scan.next();
                        System.out.println("Enter the date of return:");
                        String date;
                        date=scan.next();
                        String s2=name+" "+book+" "+date;
                        sl.add(s2);
                        Iterator itr=sl.iterator();
                        System.out.println("Student added sucessfully");
                        FileOutputStream fos1=new FileOutputStream("student.txt");
                        ObjectOutputStream oos1=new ObjectOutputStream(fos1);
                        oos.writeObject(sl);
            }
}

class Return{

            public void breturn() throws Exception{

                        FileInputStream fis=new FileInputStream("books.txt");
                        ObjectInputStream ois=new ObjectInputStream(fis);
                        ArrayList al=(ArrayList)ois.readObject();
                        System.out.println("Enter the book id and name of book:");
                        Scanner scan=new Scanner(System.in);
                        int Bid=scan.nextInt();
                        String Bname=scan.nextLine();
                        al.add(Bid,Bname);
                        System.out.println("Book returned successfully");
                        FileOutputStream fos=new FileOutputStream("books.txt");
                        ObjectOutputStream oos=new ObjectOutputStream(fos);
                        oos.writeObject(al);
                        FileInputStream fis1=new FileInputStream("student.txt");
                        ObjectInputStream ois1=new ObjectInputStream(fis1);
                        ArrayList sl=(ArrayList)ois.readObject();
                        System.out.println("Enter the token number:");
                        int token=scan.nextInt();
                        sl.remove(token);
                        FileOutputStream fos1=new FileOutputStream("student.txt");
                        ObjectOutputStream oos1=new ObjectOutputStream(fos1);
                        oos.writeObject(sl);
            }
}