import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

class Student extends Thread implements ActionListener{

            private static final WindowListener Mylistener = null;
            Frame f=new Frame();
            Frame f1;
            TextField tx1,tf;
            TextField tx2;

            public void run() {

                        Mylistener m=new Mylistener();
                        Label un=new Label("Username");
                        Label pwd=new Label("Password");
                        tx1=new TextField(30);
                        tx2=new TextField(30);
                        tx2.setEchoChar('*');
                        f.setVisible(true);
                        f.setSize(300, 300);
                        f.setTitle("VCE Library");
                        f.setLayout(new FlowLayout());
                        Button b=new Button("Login");
                        f.add(un);
                        f.add(tx1);
                        f.add(pwd);
                        f.add(tx2);
                        f.add(b);
                        b.addActionListener(this);
                        f.addWindowListener(m);

            }

            public void actionPerformed(ActionEvent arg0) {

                        String name=tx1.getText();
                        String pwd =tx2.getText();
                        if(name.equals("rishitha") && pwd.equals("rishi")) {
                        f1=new Frame();
                        CheckboxGroup cg=new CheckboxGroup();
                        Checkbox cb=new Checkbox("Book details",cg,true);
                        Label l=new Label("Token number:");
                        tf=new TextField(5);
                        f1.setLayout(new FlowLayout());
                        f1.setSize(300,300);
                        f1.setVisible(true);
                        Button b=new Button("go--->");
                        f1.add(cb);
                        f1.add(l);
                        f1.add(tf);
                        f1.add(b);
                        Action a=new Action();
                        b.addActionListener(a);
                        Mylistener m1=new Mylistener();
                        f1.addWindowListener(m1);
        	    }
	}
}

class Action extends Student implements ActionListener{

            public void actionPerformed(ActionEvent arg0) {

                        System.out.println("Enter the token no:");
                        Scanner scan =new Scanner(System.in);
                        int tokenno=scan.nextInt();
                        Ssearch s=new Ssearch();
                        try {
                           String s1=s.run(tokenno);
                        } catch (Exception e) {
                           e.printStackTrace();
                        }
            }
}

class Mylistener extends WindowAdapter{

            public void windowClosing(WindowEvent arg0) {

                        System.exit(0);
            }
}

class Librarian extends Thread{

            public void run(){

                        System.out.println("Enter your ID:");
                        Scanner scan=new Scanner(System.in);
                        int ID=scan.nextInt();
                        if(ID==100) {
                                    while(true) {

System.out.println("1.See the books\n2.Add books\n3.Issue the book\n4.Return the book\n5.Logout");
                                                int ch=scan.nextInt();
                                                switch(ch) {
                                                case 1: Observe o=new Observe();
                                       		try {
							o.observe();
						    } catch(Exception e) {

							 e.printStackTrace();
						    }break;

                                                case 2: Add a=new Add();
		System.out.println("Enter the book name which is to be added:");
		String bname=scan.nextLine();
						try {
		                                        a.add();
	                                            } catch(Exception e) {

						 e.printStackTrace();
                                                       }  break;

                                                case 3:  Issue i=new Issue();
		System.out.println("Enter the Id of book:");                                           
		int bid=scan.nextInt();
                			        try {
						 i.issue();
						 } catch(Exception e) {
						 e.printStackTrace();
				     		 }    break;

                                                case 4:  Return r=new Return();
System.out.println("Enter the book id and name of book:");
					 int Bid=scan.nextInt();
				     	 String Bname=scan.nextLine();
			                   try {
						 r.breturn();
                                             } catch(Exception e) {
						 e.printStackTrace();
				 	     }
						break;

                                                case 5:
				            System.exit(100);
                                                     break;
                                                }
                                    }
                        }
                        else {
                                    System.out.println("wrong id");
                        }
            }
}

public class Main {

            public static void main(String args[]) throws Exception {

                        System.out.println("Enter whether you are 1.student or 2.librarian : " );
                        Scanner scan= new Scanner(System.in);
                        int user=scan.nextInt();
                        Files f=new Files();
                        f.book();
                        f.student();
                        if(user== 1) {

                                    Student s=new Student();
                                    Thread t1=new Thread(s);
                                    t1.run();
                        }
                        else if(user==2) {
                                    Librarian l=new Librarian();
                                    Thread t2=new Thread(l);
                                    t2.run();
                        }
            }
}
