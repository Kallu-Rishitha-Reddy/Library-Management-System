import java.util.*;
import java.io.*;

public class Files {

            public void book() throws Exception {

                        ArrayList al=new ArrayList();
                        al.add("digital design by morris mano 4th edition");
                        al.add("java by schildt 7th addition");
                        al.add("discrete mathematics by grimaldi 5th edition");
                        al.add("digital design by mano 4th edition");
                        al.add("the girl in room 105 by chethan bhagat");
                        al.add("Everyone has a story by savi sharma");
                        al.add("ds in c by horowitz 2nd edition");
                        File f=new File("books.txt");
                        f.createNewFile();
                        FileOutputStream fos=new FileOutputStream(f);
                        ObjectOutputStream oos=new ObjectOutputStream(fos);
                        oos.writeObject(al);
            }

            public void student() throws Exception{

                        ArrayList sl=new ArrayList();
                        sl.add("satvik one indian girl 27mar");
                        sl.add("john five point someone 29jan");
                        sl.add("abraham three mistakes of my life 1feb");
                        File f=new File("student.txt");
                        f.createNewFile();
                        FileOutputStream fos=new FileOutputStream(f);
                        ObjectOutputStream oos=new ObjectOutputStream(fos);
                        oos.writeObject(sl);
            }
}
